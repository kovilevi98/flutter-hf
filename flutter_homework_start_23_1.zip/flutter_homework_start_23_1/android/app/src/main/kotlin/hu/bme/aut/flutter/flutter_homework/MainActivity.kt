package hu.bme.aut.flutter.flutter_homework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
